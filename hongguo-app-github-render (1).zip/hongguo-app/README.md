# Hongguo App — GitHub deployment

This project is a React + Vite frontend with an Express/Node.js API backend. It is **not a Streamlit/Python app**, so Streamlit Community Cloud cannot run it as-is while preserving the original UI and backend. Use Render (or another Node.js host) connected to GitHub.

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Put your Apify token in `.env` as `APIFY_TOKEN=...`.
4. Run `npm ci`.
5. Run `npm run dev` and open `http://localhost:5173`.

## Deploy from GitHub with Render

1. Create a **private** GitHub repository and upload the contents of this folder. Do not upload `.env`.
2. In Render, choose **New → Blueprint** and connect the repository.
3. Render detects `render.yaml`. Set `APIFY_TOKEN` in the service's Environment settings using your own Apify token.
4. Deploy. Render runs `npm ci && npm run build`, then `npm start`.

The Express server serves the built React UI and the `/api/*` endpoints from the same service. The Apify token stays on the server and is not sent to the browser.

## Important notes

- Do not commit `.env`, API tokens, `.cache`, `node_modules`, or `.git`.
- The cache is local to the running service and may be cleared when a free host restarts/redeploys. For durable cache, use persistent storage or a database.
- Apify actors may consume paid usage or monthly quota.
- Use downloads only for content you own or are authorized to download.
