Hongguo Drama - Streamlit
=========================

Main file: hongguo_streamlit_polished.py
Rename it to streamlit_app.py before adding to the GitHub repository,
or upload the contents as the existing streamlit_app.py.

Required packages:
- streamlit
- requests

Streamlit Secrets:
APIFY_TOKEN = "YOUR_APIFY_TOKEN"

Note:
This version keeps the existing Apify actor integration and app flows.
It improves the layout, fixes session-state initialization, and gives a
clearer message when Apify returns the monthly hard-limit error.
A genuinely different fallback API requires a compatible provider endpoint,
documentation, and valid credentials; it cannot be inferred from the Apify token.
